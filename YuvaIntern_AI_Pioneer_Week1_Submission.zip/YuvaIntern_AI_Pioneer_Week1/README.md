# Yuva Intern AI Pioneer Internship – Week 1

## Python for Machine Learning & Data Preprocessing

This project fulfills Week 1 of the AI Pioneer Internship at Yuva Intern. It demonstrates a complete preprocessing workflow using Python, NumPy, Pandas and scikit-learn.

### Project objective

The objective is to prepare a raw sample dataset for machine-learning use by:

- Loading and inspecting data
- Identifying missing and invalid values
- Removing duplicate records
- Selecting useful features
- Encoding categorical variables
- Standardizing numerical features
- Performing exploratory data analysis
- Exporting a clean ML-ready dataset

### Dataset

The project uses a **synthetic Student Performance dataset** containing 250 original records plus intentionally duplicated records and controlled missing/invalid values. No real student information is used.

Features include:

- Age
- Gender
- Study Hours Per Day
- Attendance Percentage
- Assignment Score
- Previous Semester Score
- Internet Access
- Extracurricular Activity
- Family Income
- Final Score
- Pass Status

### Preprocessing workflow

1. Load raw CSV using Pandas.
2. Inspect shape, data types, statistics and missing values.
3. Detect and remove duplicate rows.
4. Detect invalid age and percentage/score values.
5. Replace invalid values with missing values.
6. Fill numerical missing values using the median.
7. Fill categorical missing values using the mode.
8. Remove `Student_ID` because it is an identifier.
9. One-hot encode categorical variables.
10. Standardize numerical features with `StandardScaler`.
11. Convert the target `Pass_Status` to 0/1.
12. Perform EDA using bar charts, histograms, scatter plots and a correlation matrix.
13. Save the processed dataset.

### Repository structure

```text
YuvaIntern_AI_Pioneer_Week1/
├── data/
│   ├── raw/
│   │   └── student_performance_raw.csv
│   └── processed/
│       └── student_performance_cleaned.csv
├── notebooks/
│   └── YuvaIntern_Week1_Data_Preprocessing.ipynb
├── reports/
│   ├── figures/
│   └── YuvaIntern_Week1_Report.docx
├── src/
│   └── preprocess.py
├── requirements.txt
└── README.md
```

### Technologies

- Python
- NumPy
- Pandas
- Matplotlib
- scikit-learn
- Jupyter Notebook
- Microsoft Word

### How to run

```bash
pip install -r requirements.txt
jupyter notebook notebooks/YuvaIntern_Week1_Data_Preprocessing.ipynb
```

Run the notebook from top to bottom.

### Important ML note

For a future predictive model, preprocessing operations such as scaling should be fitted using the training set only and then applied to validation/test data. This prevents data leakage. The current notebook demonstrates the preprocessing concepts required by Week 1.

### Deliverables

- Jupyter Notebook
- Raw dataset
- Cleaned dataset
- EDA figures
- Python preprocessing script
- Word report
- README documentation
