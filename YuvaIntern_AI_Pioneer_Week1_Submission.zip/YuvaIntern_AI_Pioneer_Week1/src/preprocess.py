"""
Yuva Intern AI Pioneer - Week 1
Data preprocessing pipeline for a synthetic student-performance dataset.
"""

from pathlib import Path
import pandas as pd
from sklearn.preprocessing import StandardScaler

BASE = Path(__file__).resolve().parents[1]
RAW_PATH = BASE / "data" / "raw" / "student_performance_raw.csv"
OUTPUT_PATH = BASE / "data" / "processed" / "student_performance_cleaned.csv"

df = pd.read_csv(RAW_PATH)

# Correct invalid values.
df.loc[~df["Age"].between(18, 100), "Age"] = pd.NA
df.loc[~df["Attendance_Percent"].between(0, 100), "Attendance_Percent"] = pd.NA
df.loc[~df["Assignment_Score"].between(0, 100), "Assignment_Score"] = pd.NA
df.loc[~df["Previous_Semester_Score"].between(0, 100), "Previous_Semester_Score"] = pd.NA
df.loc[~df["Final_Score"].between(0, 100), "Final_Score"] = pd.NA

# Remove duplicates.
df = df.drop_duplicates().reset_index(drop=True)

numeric_cols = [
    "Age", "Study_Hours_Per_Day", "Attendance_Percent",
    "Assignment_Score", "Previous_Semester_Score", "Final_Score"
]
categorical_cols = [
    "Gender", "Internet_Access", "Extracurricular_Activity", "Family_Income"
]

# Imputation.
for col in numeric_cols:
    df[col] = df[col].fillna(df[col].median())

for col in categorical_cols:
    df[col] = df[col].fillna(df[col].mode()[0])

# Feature selection.
df = df.drop(columns=["Student_ID"])

# Separate target.
target = df["Pass_Status"]
X = df.drop(columns=["Pass_Status"])

# Encoding.
X = pd.get_dummies(X, columns=categorical_cols, drop_first=True, dtype=int)

# Standardization.
scaler = StandardScaler()
X[numeric_cols] = scaler.fit_transform(X[numeric_cols])

# Encode target.
X["Pass_Status"] = target.map({"Fail": 0, "Pass": 1}).astype(int)

X.to_csv(OUTPUT_PATH, index=False)
print(f"Saved processed data to: {OUTPUT_PATH}")
